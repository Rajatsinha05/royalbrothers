export default function Bar(){
    return(
    <div style={{width:"50px",height:"3px",backgroundColor:"#FDB605",margin:"auto"}}>
    </div>
    )
}