import React from 'react'

function Rbxsubscription() {
  return (
    <div>Rbxsubscription</div>
  )
}

export default Rbxsubscription