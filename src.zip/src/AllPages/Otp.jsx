export function Otp(){
    return(
        <div><h1>OTP</h1></div>
    )
}

