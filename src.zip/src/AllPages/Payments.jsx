import React from 'react'

function Payments() {
  return (
    <div>Payments</div>
  )
}

export default Payments