import AllRouters from "./AllRoutes/AllRouters";
import Footer from "./Components/Footer";


function App() {
  return (
 <>
 
<AllRouters/>
<Footer />

 
 </>
      
  );
}

export default App;
